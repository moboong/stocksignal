package com.example.demo.vo;

import lombok.Data;

@Data
public class SysMasVO {
	
	private String sysId;
	private String bizNm;
	private String sysNm;
	private String sysSt;
	private String passPtnType;
	private int passSize;
	private String qrUseYn;
	private String regDttm;
	
}
