# @svgr/babel-plugin-svg-em-dimensions

## Install

```
npm install --save-dev @svgr/babel-plugin-svg-em-dimensions
```

## Usage

**.babelrc**

```json
{
  "plugins": ["@svgr/babel-plugin-svg-em-dimensions"]
}
```

## License

MIT
