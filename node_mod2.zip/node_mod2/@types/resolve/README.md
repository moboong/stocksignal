# Installation
> `npm install --save @types/resolve`

# Summary
This package contains type definitions for resolve (https://github.com/browserify/resolve).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/resolve.

### Additional Details
 * Last updated: Tue, 12 May 2020 23:58:31 GMT
 * Dependencies: [@types/node](https://npmjs.com/package/@types/node)
 * Global values: none

# Credits
These definitions were written by [Mario Nebl](https://github.com/marionebl), and [Klaus Meinhardt](https://github.com/ajafff).
