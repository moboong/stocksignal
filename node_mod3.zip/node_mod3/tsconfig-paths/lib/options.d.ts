export interface Options {
    cwd: string;
}
export declare const options: Options;
