import React, { Component } from 'react';
import Frame from '../Frame';

class NotFound extends Component {

    render() {
      return (
        <div>
          NOT FOUND :
          URL 접근할 수 없는 페이지에요!
        </div>
      );
    }
}
export default NotFound;