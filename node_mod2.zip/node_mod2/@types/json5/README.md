# Installation
> `npm install --save @types/json5`

# Summary
This package contains type definitions for JSON5 (http://json5.org/).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/types-2.0/json5

Additional Details
 * Last updated: Mon, 19 Sep 2016 17:28:59 GMT
 * File structure: ProperModule
 * Library Dependencies: none
 * Module Dependencies: none
 * Global values: json5

# Credits
These definitions were written by Jason Swearingen <https://jasonswearingen.github.io>.
