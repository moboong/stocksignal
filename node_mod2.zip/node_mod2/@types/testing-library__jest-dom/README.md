# Installation
> `npm install --save @types/testing-library__jest-dom`

# Summary
This package contains type definitions for @testing-library/jest-dom (https://github.com/testing-library/jest-dom).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/testing-library__jest-dom.

### Additional Details
 * Last updated: Wed, 01 Dec 2021 00:31:12 GMT
 * Dependencies: [@types/jest](https://npmjs.com/package/@types/jest)
 * Global values: none

# Credits
These definitions were written by [Ernesto García](https://github.com/gnapse), [John Gozde](https://github.com/jgoz), and [Seth Macpherson](https://github.com/smacpherson64).
