# @svgr/babel-plugin-transform-svg-component

## Install

```
npm install --save-dev @svgr/babel-plugin-transform-svg-component
```

## Usage

**.babelrc**

```json
{
  "plugins": [
    ["@svgr/babel-plugin-transform-svg-component", { "titleProp": true }]
  ]
}
```

## License

MIT
